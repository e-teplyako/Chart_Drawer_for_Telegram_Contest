package com.teplyakova.april.telegramcontest;

public class ChartData {
    public long[]     posX;
    public LineData[] lines;
    public String type;
}
