package com.teplyakova.april.telegramcontest.Drawing;

//God i hope noone sees this abomination

public class BaseChartDrawer {
    //TODO implement this
}
