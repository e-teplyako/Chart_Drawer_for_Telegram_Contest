package com.example.android.telegramcontest.Interfaces;

public interface SliderObserver {
    void setBorders (float normPos1, float normPos2);
}
