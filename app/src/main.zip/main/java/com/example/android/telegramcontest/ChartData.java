package com.example.android.telegramcontest;

import java.util.ArrayList;

public class ChartData {
    public long[]     posX;
    public LineData[] lines;
}
