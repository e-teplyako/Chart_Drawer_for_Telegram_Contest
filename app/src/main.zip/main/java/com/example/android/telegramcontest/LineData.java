package com.example.android.telegramcontest;

public class LineData {
    public long[]   posY;
    public String   id;
    public String   name;
    public int      color;
}
